#include "shopping_cart.h"

namespace pos {

	//constructor
	shopping_cart::shopping_cart() {
		cart_total_count = 0;
		cart_total_price = 0;

	}
	//destructor
	shopping_cart::~shopping_cart() { //cart_list ���� cart_item �ϳ��� delete
		list<cart_item*>::iterator iter = this->cart_list.begin();
		cart_item* cart_item;
		for (iter = this->cart_list.begin(); iter != this->cart_list.end(); iter++) {
			cart_item = &(**iter);
			delete(cart_item);
		}
	}
	//public method
	int shopping_cart::get_cart_total_count() {
		return this->cart_total_count;
	}
	int shopping_cart::get_cart_total_price() {
		return this->cart_total_price;
	};

	void shopping_cart::add_item(cart_item* item) {
		cart_list.push_back(item);
		int count = item->get_total_count();
		cart_total_count += count; //���� �����ֱ� 
		cart_total_price += count * item->get_price(); //����*����
	};

	list<cart_item*> shopping_cart::get_cart_list() { //getter of cart_list
		return this->cart_list;
	}
}